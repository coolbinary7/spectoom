#!/bin/sh
cd "$(dirname "$0")"
chmod +x ./run.sh 2>/dev/null || true
./run.sh
