#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
APP_VERSION="2.8.1-local"
PORT="${PORT:-8080}"

printf '\nSpectoom %s - demarrage macOS/Linux\n\n' "$APP_VERSION"

python3 -m pip install --disable-pip-version-check -r requirements.txt

(
  python3 - "$PORT" "$APP_VERSION" <<'PY'
import json, subprocess, sys, time, urllib.request, webbrowser
port=sys.argv[1]
expected=sys.argv[2]
url=f"http://127.0.0.1:{port}/api/health"
open_url=f"http://127.0.0.1:{port}/?v={expected}"
for _ in range(160):
    try:
        with urllib.request.urlopen(url, timeout=.8) as response:
            data=json.load(response)
        if data.get('service') == 'Spectoom' and data.get('version') == expected:
            try:
                subprocess.Popen(['open', open_url])
            except Exception:
                webbrowser.open(open_url)
            break
    except Exception:
        time.sleep(.25)
PY
) &

python3 server.py
